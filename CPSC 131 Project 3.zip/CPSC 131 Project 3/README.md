# Project 3
## CSUF CPSC 131, Fall 2020

MUST EDIT WITH YOUR OWN NAME AND GROUP MEMBER'S NAME AND EMAIL ID's IN THE FOLLOWING FORMAT

Group members:
- Ada Lovelace adalovelace@csu.fullerton.edu
- Charles Babbage charlesbab@csu.fullerton.edu
